module.exports = {
	sentiment: require('./sentiment')
};
